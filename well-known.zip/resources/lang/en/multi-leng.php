<?php

return [

    'esp' => 'Spanish',

    'ing' => 'English',

    'idi' => 'Language',

    'ingnav' => 'Login',

    'ininav' => 'Home',

    'regnav' => 'Register',

    'lognav' => 'Logout',

    'optnav' => 'Options',

    'ingpla' => 'Access to the Platform',

    'salwel1' => 'Hello',

    'salwel2' => ', click here to go back to Home...',

    'salwel3' => 'Innovative Teacher Network',

    'admusu' => 'Administer Users',

    'admper' => 'Permissions',

    'admrol' => 'Roles',

    'admusers' => 'Users',

    'admprof' => 'User Profile',

    'nologet' => 'Unauthorized User',

    'voling' => 'Re-enter the Platform',

    'recnot' => 'Resource not found',

    'volatr' => 'Go Back',

    'olvcon' => 'Forgot your password?',

    'emadir' => 'E-Mail Address',

    'pasuser' => 'Password',

    'nomuser' => 'Name',

    'suruser' => 'Surname',

    'idioma' => 'English',

    'userdetal' => 'User Details',

    'addnewuser' => 'Add New User',

    'areyousur' => 'Are you sure?',

    'multi1' => 'Administrator',

    'multi2' => 'Academics',

    'multi3' => 'News',

    'multi4' => 'Students',

    'caracteresname' => 'Minimum 2 characters, maximum 70 characters',

    'caracterespass' => 'Minimum 6 characters, maximum 10 characters',

    'indiquerol' => 'Indicate what access privileges the user will have. By default it is student.',

    'noacademicos' => 'To add this type of user profile, you must first assign at least one full category and subcategory.',

    'noacademicos1' => 'To add this type of user profile, you must first assign at least one Academic with their respective assigned subcategory.',

    'error1' => 'We were unable to process your request, please contact the administrator. Mistake: ',

    'admcatsup' => 'Manage Cat.',

    'admcat' => 'Categories',

    'admsubcat' => 'Sub-Categories',

    'addadmcat' => 'Add-Categories',

    'namecat' => 'Category Name',

    'infonamecat' => 'The category name is mandatory, with a minimum of 2 characters and a maximum of 50 characters. The category name is unique and must not be repeated',

    'textingfolder' => 'Your category was entered correctly',

    'addsubcatto' => 'Add Sub-category to: ',

    'namesubcat' => 'Name Sub-category',

    'infonamesubcat' => 'The name of the sub-category is mandatory, with a minimum of 2 characters and a maximum of 50 characters.',

    'textingsubfolder' => 'The sub-category was entered correctly',

    'textingsubcarpetano' => 'We could not create the sub-category',

    'fechcrecat' => 'Creation Date: ',

    'editarcateg' => 'Edit Category',

    'eliminarcateg' => 'Delete Category',

    'editarsubcateg' => 'Edit Sub-Category',

    'eliminarsubcateg' => 'Delete Sub-Category',

    'addsubcatbtn' => 'Add Sub-Category',

    'texteditcarpeta' => 'Your category was edited correctly',

    'formerror1' => '-. Please enter a valid name of more than 2 characters.',

    'formerror2' => "-. We couldn't connect to the server. Please try again later.",

    'formerror3' => '-. The name is not available.',

    'textelicarpeta' => 'Your category was successfully deleted',

    'formerror4' => 'This action will make the following changes:',

    'formerror5' => '.- Will remove all sub-categories associated with it.',

    'formerror6' => '.- The teachers associated with it.',

    'formerror7' => '.- The students associated with it.',

    'formerror8' => '.- The resources in PDF format associated with it.',

    'formerror9' => 'Are you sure to continue?',

    'textosref1' => 'Edit Sub-Category: ',

    'texteditsubfolder' => 'The sub-category was edited correctly',

    'textelisubfolder' => 'The sub-category was successfully deleted',

    'documdig' => 'Digital Documents',

    'dusdocbtn' => 'Search Teachers',

    'formerror10' => 'You must select at least one option',

    'formerror11' => 'No selections',

    'formerror12' => 'Filter',

    'formerror13' => 'You must select the category or categories in which the Academic will participate. You must select at least one option',

    'formerror15' => 'The user',

    'formerror16' => ', was created successfully.',

    'formerror17' => ' Notification email was not sent to the entered user.',

    'formerror18' => ' A notification email was sent to the user entered with the platform access data.',

    'formerror19' => ' We could not send the Notification email. We have an error sending email, please contact the platform administrator.',

    'formerror20' => 'Manage Blog',

    'formerror21' => 'Blog Categories',

    'formerror22' => 'Actions',

    'formerror23' => 'Add New Category',

    'formerror24' => 'View Posts',

    'formerror25' => 'Created By',

    'formerror26' => 'Description',

    'formerror27' => 'Image',

    'formerror28' => 'Visits',

    'formerror29' => 'Title',

    'formerror30' => 'Add New Post',

    'formerror31' => 'You must select the category in which the publication is included. You must select at least one option',

    'formerror32' => 'Content',

    'formerror33' => 'Enter the content of your post', 

    'formerror34' => 'This selection is not mandatory',

    'formerror35' => 'Select the tags to which your publication will be associated, this will allow you to group related publications',

    'formerror36' => 'Main Image',

    'formerror37' => 'This will be the image, which will be displayed in the Posts search. Only images in .jpg, .jpeg, .png format, with a width of 600 pixels x a height of 400 pixels, are accepted.',

    'formerror38' => 'This will be the image, with a width of 600 pixels x a height of 400 pixels, are accepted.',

    'formerror39' => 'Enter a valid post name of more than 2 characters',

    'formerror40' => 'You must select at least one category, related to your post.',

    'formerror41' => 'Enter the content of your post.',

    'formerror42' => 'The Main Image is required',

    'formerror43' => 'To enter your post, you must fix the following errors:',

    'formerror44' => 'Post saved successfully.',

    'formerror45' => 'We could not save your post. Please try again.',

    'formerror46' => 'Dear user',

    'formerror47' => 'There are no comments on this post yet.',

    'formerror48' => 'Comments.',

    'formerror49' => 'Enter your comment.',

    'formerror50' => 'Category',

    'formerror51' => '-. Please enter a comment of at least 10 characters.',

    'formerror52' => 'To enter your comment you must solve the following errors: ',

    'formerror53' => 'Your comment was entered correctly.',

    'formerror54' => 'The comment was successfully deleted.',

    'formerror55' => 'The Post was deleted successfully.',

    'formerror56' => 'Post edited successfully.',

    'formerror57' => 'We could not edit your post. Please try again.',

    'formerror58' => 'Blog Tags',

    'formerror59' => 'Add Tag',

    'formerror60' => 'Tag Name',

    'formerror61' => 'The tag name is mandatory, with a minimum of 2 characters and a maximum of 50 characters. The tag name is unique and should not be repeated',

    'formerror62' => 'Edit Tag',

    'formerror63' => 'Delete Tag',

    'formerror64' => 'The selected Tag cannot be deleted while it is associated with active Posts.',

    'formerror65' => 'Your tag was successfully edited',

    'formerror66' => 'Your tag was successfully removed',

    'formerror67' => 'The selected Category cannot be deleted while it is associated with active Posts.',

    'formerror68' => 'Posts',

    'formerror69' => 'Visitors',

    'formerror70' => 'Watch Now',

    'formerror71' => 'Number of Visits',

    'formerror72' => 'Number of times the publication has been viewed',

    'formerror73' => 'This information is updated every 10 minutes.',

    'formerror74' => 'Digital Library',

    'formerror75' => 'Forums',

    'formerror76' => 'View',

    'formerror77' => 'There are no available digital resources associated with this teacher at this time.',

    'formerror78' => 'Date',

    'formerror79' => 'Description',

    'formerror80' => 'Author',

    'formerror81' => 'Name',

    'formerror82' => 'Digital Resources',

    'formerror83' => 'Teacher Name',

    'formerror84' => 'There are no Teachers associated with this sub-category: ',

    'formerror86' => 'Number of comments that the post has.',

    'formerror87' => 'Number of views that the publication has.',

    'formerror88' => 'Continue reading...',

    'formerror89' => 'Refresh',

    'formerror90' => 'Assigned Blocks',

    'formerror91' => 'Active Chats',

    'formerror92' => 'Add New Chats',

    'formerror93' => 'Download',

    'formerror94' => 'Add New Documents',

    'formerror95' => 'Your digital document was entered correctly.',

    'formerror96' => 'This document has problems. Contact the administrator.',

    'formerror97' => 'Document Name',

    'formerror98' => 'Enter document name',

    'formerror99' => 'The document name is mandatory, with a minimum of 2 characters and a maximum of 50 characters.',

    'formerror100' => 'Author',

    'formerror101' => 'Enter author name',

    'formerror102' => "The author's name is not mandatory, but if you do so it must be a minimum of 2 characters and a maximum of 50 characters.",

    'formerror103' => 'Enter document description',

    'formerror104' => 'The document description is not mandatory, but if you do so it must be a minimum of 2 characters and a maximum of 50 characters.',

    'formerror105' => 'Select a File',

    'formerror106' => 'You must select a file in .pdf format',

    'formerror107' => 'Please enter a valid file',

    'formerror108' => 'Please enter a valid author name of at least 2 characters',

    'formerror109' => 'Enter a valid description of at least 2 characters',

    'formerror110' => 'Document edited successfully.',

    'formerror111' => 'Document deleted successfully.',

    'formerror112' => 'Active Participants',

    'formerror113' => 'Waiting Participants',

    'formerror114' => 'Participants Removed',

    'formerror115' => 'Select where you will create this forum, so that the users you accept in this category can interact',

    'formerror116' => 'Select at least one Item',

    'formerror117' => 'This name has already been entered',

    'formerror118' => 'The category for the forum has been entered correctly.',

    'formerror119' => 'The category for the forum could not be entered.',

    'formerror120' => 'Moderate Forum',

    'formerror121' => 'Dear Teacher:',

    'formerror122' => 'There are no active users in the Forum.',

    'formerror123' => 'There are no users waiting to enter the Forum.',

    'formerror124' => 'There are no users removed from this Forum.',

    'formerror125' => 'View Users',

    'formerror126' => 'There are no active comments in this Forum category.',

    'formerror127' => 'The forum category has been edited successfully.',

    'formerror128' => 'The forum category could not be edited.',

    'formerror129' => 'Are you sure to delete this category? This action is not reversible and will eliminate the users attached to it, as well as their comments.',

    'formerror130' => 'The forum category has been successfully deleted.',

    'formerror131' => 'Votes',

    'formerror132' => 'Topics',

    'formerror133' => 'Visits',

    'formerror134' => 'Users',

    'formerror135' => 'Add Topics',

    'formerror136' => 'Active Topics',

    'formerror137' => 'Add New topic',

    'formerror138' => 'We have an error entering your new theme. contact the administrator',

    'formerror139' => 'Your new theme has been successfully added',

    'formerror140' => "We couldn't add your new theme",

    'formerror141' => 'Topic Title',

    'formerror142' => 'The topic title is required, with a minimum of 2 characters and a maximum of 250 characters.',

    'formerror143' => 'Enter a valid topic title',

    'formerror144' => 'Enter the content of your topic',

    'formerror145' => 'Your vote was entered correctly',

    'formerror146' => 'Your answer was entered correctly',

    'formerror147' => 'Vote obtained for the answer, through the score provided by the users, who are registered in this category.',

    'formerror148' => 'Submit vote',

    'formerror149' => 'Click to see User information',

    'formerror150' => 'Published',

    'formerror151' => 'go by',

    'formerror152' => 'Response #',

    'formerror153' => 'Votes',

    'formerror154' => 'Responses',

    'formerror155' => 'Vote obtained for the topic, through the score provided by users who are registered in this category.',

    'formerror156' => 'Responses entered by users who are registered in this category.',

    'formerror157' => 'Number of times the topic has been viewed, by users who are registered in this category.',

    'formerror158' => 'Reply',

    'formerror159' => 'Add response',

    'formerror160' => 'Click here to attach your response.',

    'formerror161' => 'Assign Score to Topic',

    'formerror162' => "Are you sure to delete this response?. This action is not reversible and will eliminate the vote obtained.",

    'formerror163' => 'The entered response was successfully deleted.',

    'formerror164' => 'Click to see the full content of the topic entered by the user.',

    'formerror165' => 'Summary',

    'formerror166' => 'Filter by:',

    'formerror167' => 'Most Voted',

    'formerror168' => 'More Answers',
    
    'formerror169' => 'Most Viewed',

    'formerror170' => 'Active Users List',

    'formerror171' => 'Waiting Users List',
    
    'formerror172' => 'Deleted Users List',

    'formerror173' => 'Entry Date',

    'formerror174' => 'Access to Available Forums',

    'formerror175' => 'Forum-Category Name',

    'formerror176' => 'Request Access',

    'formerror177' => 'Request Waiting',

    'formerror178' => 'Enter Forum',

    'formerror179' => 'Access Denied',

    'formerror180' => 'Your request to enter the selected forum has been entered correctly. You must wait for your request to be approved by the teacher, to be able to access and interact with it.',

    'formerror181' => 'We were unable to create your access request. Contact the Administrator.',

    'formerror182' => 'You already have a request to join this Forum waiting.',

    'formerror183' => 'You already have an active request in this Forum.',

    'formerror184' => 'You have been denied access to this Forum.',

    'formerror185' => 'Authorize Access',

    'formerror186' => 'Deny Access',

    'formerror187' => 'Forum access was enabled',

    'formerror188' => 'Teaching Documents',

    'formerror189' => 'Add Category',

    'formerror190' => 'Add Documents',

    'formerror191' => 'Document Name',

    'formerror192' => 'To Add Documents, you must have at least one category available.',

    'formerror193' => 'Select a Category',

    'formerror194' => 'Your Document was successfully edited',

    'formerror195' => 'Categories-Documents',

    'formerror196' => 'Last Update',

    'formerror197' => 'Category edited successfully.',

    'formerror198' => 'Share Document',

    'formerror199' => 'Copy',

    'formerror200' => 'The document url has been copied successfully',

    'formerror201' => 'Copy URL',

    'formerror202' => 'Brainstorm',

    'formerror203' => 'Add Ideas',

    'formerror204' => 'Add New Idea',

    'formerror205' => 'Your information has been entered correctly',

    'formerror206' => 'Dear User, you are not authorized to perform these actions. Please contact the Platform administrator.',

    'formerror207' => 'Entered',

    'formerror208' => 'Attached Idea',

    'formerror209' => 'We could not find information about the requested idea.',

    'formerror210' => 'Click to see the complete content of the developed idea.',

    'formerror211' => 'go.',

    'formerror212' => 'Click here to add your new idea.',

    'formerror213' => 'Your information was entered correctly.',

    'formerror214' => 'We were unable to enter your information. Please try again.',

    'formerror215' => 'Are you sure you delete this Idea. This action is not reversible and will eliminate all attached ideas.',

    'formerror216' => 'This option allows you to edit the Idea.',

    'formerror217' => 'Are you sure you delete this attached Idea. This action is not reversible.',

    'formerror218' => 'This option allows you to edit the attached Idea.',

    'formerror219' => 'Your attached idea was successfully deleted.',

    'formerror220' => 'Your idea was successfully edited',

    'formerror221' => 'Your main idea was successfully deleted.',

    'formerror222' => 'Link-Redirect',

    'formerror223' => 'Configure Link',
    
    'formerror224' => 'Go to Link',

    'formerror225' => 'Example www.google.com',

    'formerror226' => 'Minimum 4 characters, maximum 70 characters. You must initialize with the characters www. , so that it passes the validation process',

    'formerror227' => 'Add',

    'formerror228' => 'Enter a valid URL/LINK.',

    'formerror229' => 'Redirect URL/LINK was successfully added',

    'formerror230' => 'Redirect URL/LINK was not added correctly',

    'formerror231' => 'Redirect URL/LINK was successfully edited',

    'formerror232' => 'Redirect URL/LINK was successfully removed',

    'formerror233' => 'Profession',

    'formerror234' => 'Enter your occupation, to help connect with other users. Minimum 2 characters, maximum 50 characters.',

    'formerror235' => 'This option allows you to enable or disable your user profile from appearing in connection searches for other Users.',

    'formerror236' => 'User Profile Tags',

    'formerror237' => 'The user tag was entered correctly.',
    
    'formerror238' => 'The tag name has already been entered previously',

    'formerror239' => 'Send email to: ',

    'formerror240' => 'Subject',

    'formerror241' => 'Message',

    'formerror242' => 'Enter the subject of your email',

    'formerror243' => 'Enter your email message',

    'formerror244' => 'Search for users and connect',

    'formerror245' => 'Your email was sent successfully.',

    'formerror246' => 'We could not get your email to the recipient. Please try again.',

    'formerror247' => 'you have been sent the following message from the Red Docente Innovador platform.',

    'formerror248' => 'Your password has been successfully changed.',

    'formerror249' => 'These are your new login details:',

    'formerror250' => 'Thank you very much for using our services.',

    'formerror251' => 'An associated account has been created on our Platform.',

    'formerror252' => 'Press the link to continue',

    'formerror253' => 'This is the message sent: ',

    'formerror254' => 'Send Email',

    'formerror255' => 'Call Number',

    'formerror256' => 'Chats Categories',

    'formerror257' => 'Chat Category Name',

    'formerror258' => 'Select where you will create this chat, so that the users accepted by you in this category can interact',

    'formerror259' => 'Go to Chat',
    
    'formerror260' => 'There are no active users in the Chat.',

    'formerror261' => 'There are no users waiting to enter the Chat.',

    'formerror262' => 'There are no users removed from this Chat.',

    'formerror263' => 'View Document',

    'formerror264' => 'External Link I',

    'formerror265' => 'External Link II',

    'formerror266' => 'Al eliminar esta categoría, se deshabilitarán todos los documentos asociados a ella.',

    'formerror267' => 'Training',

    'formerror268' => 'Extension',

    'formerror269' => 'Innovation Projects',

    'formerror270' => 'Resources',

    'formerror271' => 'Congress',

    'formerror272' => 'Chat Cycles',

    'formerror273' => 'Workshops',

    'formerror274' => 'Bases',

    'formerror275' => 'Application',

    'formerror276' => 'Video-Library',

    'formerror277' => 'Category Chat',

    'formerror278' => 'Go to Chat',

    'formerror279' => 'Your request to join the chat has been notified to the teacher. He will proceed to validate or reject your entry.',

    'formerror280' => 'Dear user, you are not authorized to enter the chat: ',

    'formerror281' => 'Users registered in the Chat',

    'formerror282' => 'Select a user to start the chat.',

    'formerror283' => 'Category',

    'formerror284' => 'Sub-Category',

    'formerror285' => 'URL Redirect',

    'formerror286' => 'Enter the redirect url with valid initial format https://www.',

    'formerror287' => 'Format https://www.',

    'formerror288' => 'Link Type',

    'formerror289' => 'Specify whether the link entered will be viewed within the platform or will be a redirection link to an external website',

    'formerror290' => 'Embedded',

    'formerror291' => 'External',

    'formerror292' => 'Go to link ',

    'formerror293' => 'Enter valid sub-category name',

    'formerror294' => 'External link edited successfully.',

    'formerror295' => 'External link successfully deleted.',

    'formerror296' => 'Se agregó correctamente la sub-categoría',

    'formerror297' => 'Profile type',

    'formerror298' => 'Specify the type of profile and organization to which your account will be associated.',

    'formerror299' => 'UST active student',

    'formerror300' => 'UST graduated student',

    'formerror301' => 'Active student Other Universities',

    'formerror302' => 'Student graduated from Other Universities',

    'formerror303' => 'Others...',

    'formerror304' => 'Specify your profile type or Institution',

    'formerror305' => 'Confirm your password',

    'formerror306' => 'Reset Password',

    'formerror307' => 'E-Mail Address',

    'formerror308' => 'Send Password Reset Link',
    
];