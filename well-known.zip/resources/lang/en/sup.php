<?php
return [
  'salir' => 'Exit',
  'link1' => 'Board',
   'link2' => 'Manage Users',
   'fra1' => "Email Signature Footer",
   'selec' => 'Select',
   'inst' => 'Instructions to embed your signature in',
   'copiada' => 'Signature copied successfully!',
   'copf' => 'Copy Signature',
   'verf' => 'View HTML',
   'estu' => 'Dear User:',
   'sehase' => 'A digital signature footer has been selected',
   'pupro' => 'You can proceed to copy and attach your digital signature in your email provider.',
   'cerrar' => 'Close',
  ]
?>