<?php
 return ['salir' => 'Logout', 'link1' => 'Dashboard', 'link2' => 'Manage', 'link3' => 'User Profile']
?>