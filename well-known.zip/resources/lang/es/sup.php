<?php
return [
 'salir' => 'Salir',
 'link1' => 'Tablero',
  'link2' => 'Administrar Usuarios',
  'fra1' => "Pie de Firma Email",
  'selec' => 'Seleccionar',
  'inst' => 'Instrucciones para integar su firma en',
  'copiada' => 'Firma copiada correctamente!',
  'copf' => 'Copiar Firma',
  'verf' => 'Ver HTML',
  'estu' => 'Estimado Usuario:',
  'sehase' => 'Se ha seleccionado un pie de firma digital',
  'pupro' => 'Puede proceder a copiar y adjuntar su firma digital en su proveedor de correos.',
  'cerrar' => 'Cerrar',
  ]
?>