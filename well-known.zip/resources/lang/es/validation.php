<?php

return [
    'custom' => [
        'g-recaptcha-response' => [
            'required' => 'Por favor valide que este proceso no es automatizado.',
            'captcha' => 'Captcha error! Comuniquese con el administrador.',
        ],
    ],
];