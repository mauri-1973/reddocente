<?php if(Session::has('primary') || Session::has('info') || Session::has('success') || Session::has('warning') || Session::has('danger')): ?>
<div class="" style="margin-top:6%;margin-bottom:-6%;">
    <div class="row">
        <div class="col-md-7 col-lg-7 col-xs-12 col-sm-12 offset-md-2">
            <!-- <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?> -->

            <?php if(session('primary')): ?>
            <div class="alert alert-primary alert-dismissible fade show" style="margin-bottom:30px !important;">
                <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                <i class="nc-icon nc-simple-remove"></i>
                </button>
                <span>
                <?php echo e(session('primary')); ?></span>
            </div>
            <?php endif; ?>

            <?php if(session('info')): ?>
            <div class="alert alert-info alert-dismissible fade show" style="margin-bottom:30px !important;">
                <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                <i class="nc-icon nc-simple-remove"></i>
                </button>
                <span>
                <?php echo e(session('info')); ?></span>
            </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" style="margin-bottom:30px !important;">
                <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                <i class="nc-icon nc-simple-remove"></i>
                </button>
                <span>
                <?php echo e(session('success')); ?></span>
            </div>
            <?php endif; ?>

            <?php if(session('warning')): ?>
            <div class="alert alert-warning alert-dismissible fade show" style="margin-bottom:30px !important;">
                <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                <i class="nc-icon nc-simple-remove"></i>
                </button>
                <span>
                <?php echo e(session('warning')); ?></span>
            </div>
            <?php endif; ?>

            <?php if(session('danger')): ?>
            <div class="alert alert-danger alert-dismissible fade show" style="margin-bottom:30px !important;">
                <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                <i class="nc-icon nc-simple-remove"></i>
                </button>
                <span>
                <?php echo e(session('danger')); ?></span>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH /home/desarro3/public_html/santotomas/resources/views/errors/custom-message.blade.php ENDPATH**/ ?>