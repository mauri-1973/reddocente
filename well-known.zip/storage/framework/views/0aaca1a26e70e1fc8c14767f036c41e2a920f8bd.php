<?php $__env->startSection('content'); ?>
<div class="wrapper ">
    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
        <?php echo $__env->make('layouts.partials.side-bar-adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('user')): ?>
        <?php echo $__env->make('layouts.partials.side-bar-est', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('blog')): ?>
        <?php echo $__env->make('layouts.partials.side-bar-blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('docente')): ?>
        <?php echo $__env->make('layouts.partials.side-bar-docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <div class="main-panel">
        <!-- nav bar include -->
        <?php echo $__env->make('layouts.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('errors.custom-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        

        <?php echo $__env->yieldContent('index'); ?>

        <!-- <?php echo $__env->make('layouts.partials.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   -->
        <!-- include footer -->
        <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/desarro3/public_html/santotomas/resources/views/home.blade.php ENDPATH**/ ?>