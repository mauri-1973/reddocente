<?php $__env->startSection('content'); ?>
<br><br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
            
                <div class="card-header bg-success my-auto">
                    <a href="<?php echo e(route('welcome')); ?>" class="my-auto" style="font-size:18px;">
                        <img src="<?php echo e(url('imagenes/logo-ust.svg')); ?>" alt="" width="50" height="44" class="d-inline-block align-text-top">
                        Universidad Santo Tomás
                    </a>
                </div>
                <div class="card-header">                     
                    <h4 class="" style="text-align:center;"><?php echo e(trans('multi-leng.regnav')); ?></h4>
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="form-label"><b><?php echo e(__('lang.nombreuser')); ?></b> &nbsp;&nbsp;<i style="color:#004238;font-size:18px;" class="fa fa-info-circle" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('multi-leng.caracteresname')); ?>" data-html="true"></i>&nbsp; <small style="color:red;font-size:8px;">(* <?php echo e(__('lang.infoobli')); ?>)</small></label>
                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(trans('lang.nombreuser')); ?>" minlength="2" maxlength="50" required autocomplete="<?php echo e(trans('lang.nombreuser')); ?>" autofocus>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label"><b><?php echo e(__('lang.apellidouser')); ?></b> &nbsp;&nbsp;<i style="color:#004238;font-size:18px;" class="fa fa-info-circle" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('multi-leng.caracteresname')); ?>" data-html="true"></i>&nbsp; <small style="color:red;font-size:8px;">(* <?php echo e(__('lang.infoobli')); ?>)</small></label>
                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="surname" value="<?php echo e(old('surname')); ?>" placeholder="<?php echo e(trans('lang.apellidouser')); ?>" minlength="2" maxlength="50" required autocomplete="<?php echo e(trans('lang.apellidouser')); ?>" autofocus>
                            <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label"><b><?php echo e(__('lang.email')); ?></b> &nbsp;&nbsp;<i style="color:#004238;font-size:18px;" class="fa fa-info-circle" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('lang.emailuser')); ?>" data-html="true"></i> &nbsp;<small style="color:red;font-size:8px;">(* <?php echo e(__('lang.infoobli')); ?>)</small></label>
                            <input id="email" type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" minlength="2" maxlength="50" required autocomplete="Email" autofocus>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label"><b><?php echo e(__('lang.moviluser')); ?></b> &nbsp;&nbsp;<i style="color:#004238;font-size:18px;" class="fa fa-info-circle" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('lang.numceluser')); ?>" data-html="true"></i>&nbsp; <small style="color:red;font-size:8px;">(* <?php echo e(__('lang.infoobli')); ?>)</small></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="mobile" value="<?php echo e(old('mobile')); ?>" placeholder="<?php echo e(trans('lang.moviluser')); ?>" minlength="9" maxlength="9" pattern="\d*" title="<?php echo e(trans('lang.menemp')); ?>" onkeypress="return valideKeycel(event);"  required>
                            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label"><b><?php echo e(__('multi-leng.formerror297')); ?></b> &nbsp;&nbsp;<i style="color:#004238;font-size:18px;" class="fa fa-info-circle" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('multi-leng.formerror298')); ?>" data-html="true"></i> &nbsp;<small style="color:red;font-size:8px;">(* <?php echo e(__('lang.infoobli')); ?>)</small></label>
                            <select class="form-control <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipo" id="tipo">
                                <option value="1" selected><?php echo e(__('multi-leng.formerror299')); ?></option>
                                <option value="2"><?php echo e(__('multi-leng.formerror300')); ?></option>
                                <option value="3"><?php echo e(__('multi-leng.formerror301')); ?></option>
                                <option value="4"><?php echo e(__('multi-leng.formerror302')); ?></option>
                                <option value="5"><?php echo e(__('multi-leng.formerror303')); ?></option>
                            </select>
                            <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group" style="display:none;" id="divotros">
                            <label for="otros" class="col-form-label text-md-right"><b><?php echo e(__('multi-leng.formerror304')); ?></b> &nbsp;&nbsp;<i style="color:#004238;font-size:18px;" class="fa fa-info-circle" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('multi-leng.formerror298')); ?>" data-html="true"></i> &nbsp;<small style="color:red;font-size:8px;">(* <?php echo e(__('lang.infoobli')); ?>)</small></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['otros'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="otros" name="otros" value="<?php echo e(old('otros')); ?>" placeholder="<?php echo e(__('multi-leng.formerror304')); ?>" minlength="2" maxlength="50" title="<?php echo e(trans('lang.menemp')); ?>">
                            <?php $__errorArgs = ['otros'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="password" class="form-label text-md-right"><b><?php echo e(__('multi-leng.pasuser')); ?></b>&nbsp;&nbsp;<i style="color:#004238;font-size:18px;" class="fa fa-info-circle" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('multi-leng.caracterespass')); ?>" data-html="true"></i>&nbsp; <small style="color:red;font-size:8px;">(* <?php echo e(__('lang.infoobli')); ?>)</small></label>
                            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password" minlength="6" maxlength="12" placeholder="<?php echo e(trans('lang.respassc')); ?>">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="password_confirmation" class="col-form-label text-md-right"><b><?php echo e(__('multi-leng.formerror305')); ?></b>&nbsp;&nbsp;<i style="color:#004238;font-size:18px;" class="fa fa-info-circle" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('multi-leng.caracterespass')); ?>" data-html="true"></i>&nbsp; <small style="color:red;font-size:8px;">(* <?php echo e(__('lang.infoobli')); ?>)</small></label>
                            <input id="password_confirmation" type="password" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" placeholder="<?php echo e(__('multi-leng.formerror305')); ?>" minlength="6" maxlength="12" required autocomplete="new-password">
                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <button type="submit" class="btn btn-success"><?php echo e(trans('lang.textprof7')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-script'); ?>

<script type="text/javascript">

    

    $(document).ready(function() {

        $(function () {

            $('[data-toggle="tooltip"]').tooltip()

        });

    });
    $("#tipo").change(function(){
        if($(this).val() == 3 || $(this).val() == 4 || $(this).val() == 5)
        {
            $("#divotros").css("display", "block");
            $("#otros").val("");
        }
        else
        {
            $("#divotros").css("display", "none");
            $("#otros").val("");
        }
    });
    function valideKeycel(evt)

    {

        var code = (evt.which) ? evt.which : evt.keyCode;



        if(code==8) 

        { // backspace.

            return true;

        }

        else if(code>=48 && code<=57) 

        { // is a number.

            return true;

        } 

        else

        { // other keys.

            return false;

        }

    }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/desarro3/public_html/santotomas/resources/views/auth/register.blade.php ENDPATH**/ ?>