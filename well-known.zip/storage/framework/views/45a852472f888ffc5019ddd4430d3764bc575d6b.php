<?php echo e($slot); ?>

<?php /**PATH /home/desarro3/public_html/santotomas/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>