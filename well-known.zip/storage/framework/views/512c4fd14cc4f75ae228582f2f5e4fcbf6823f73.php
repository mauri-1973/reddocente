<?php $__env->startSection('title'); ?>

<?php echo e(Auth::user()->name); ?>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('extra-css'); ?>

<style>

    #nocat

    {

       color: red;

    }

</style>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('index'); ?>

<div class="content">

    <div class="row">

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <div class="card">

                <div class="">

                    <h3><?php echo e(trans('multi-leng.formerror68')); ?></h3>

                </div>

                <div class="card-body">

                    <table id="dt-mant-table" class="table table-bordered display responsive nowrap" style="width:100%">

                        <thead>

                            <tr>

                                <th><?php echo e(trans('multi-leng.formerror68')); ?></th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row => $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($row % 2 == 0): ?>

                            <tr> 

                                <td style="white-space:normal;" data-order="<?php echo e($row); ?>">

                                    <section>

                                        <div class="container py-3">

                                            <div class="card shadow-sm bg-success rounded-3 h-100">

                                                <div class="row ">

                                                    <div class="col-md-4">

                                                        <img style="background-color:#fff;" src="<?php echo e($posts->thumbnail ? asset('storage/blog/imagenes/'.$posts->thumbnail) : asset('storage/logos/ust3.png')); ?>" class="w-100">

                                                    </div>

                                                    <div class="col-md-8 px-3">

                                                        <div class="card-block px-3">

                                                            <a href="#">

                                                                <h3 class="card-text"> <?php echo e($posts->title); ?></h3>

                                                            </a>

                                                            <p class="text-white">

                                                            <?php echo e(trans('multi-leng.formerror25')); ?> <a href="#" class="text-white">&nbsp;<?php echo e($posts->nameus); ?> <?php echo e($posts->surnameus); ?>&nbsp;&nbsp;-</a> 

                                                                <span class="text-white">&nbsp;&nbsp;<?php echo e(trans('multi-leng.formerror78')); ?>: <?php echo e($posts->created_at->format('d-m-Y')); ?>&nbsp;&nbsp;</span>

                                                                <span class="d-inline float-end text-white">

                                                                <i class="fa fa-comment fa-2x text-white" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="<?php echo e(trans('multi-leng.formerror86')); ?> "></i>

                                                                &nbsp;&nbsp;

                                                                    <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inf => $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                        <?php if($info[$inf]['idpost'] == $posts->id): ?>

                                                                            <?php echo e($info[$inf]['nomcom']); ?>


                                                                        <?php endif; ?>

                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                &nbsp;&nbsp;

                                                                </span>

                                                                <span class="d-inline float-end text-white">

                                                                <i class="fa fa-eye fa-2x text-white" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="<?php echo e(trans('multi-leng.formerror87')); ?> "></i>

                                                                &nbsp;&nbsp;<?php echo e((int)$posts->read_count); ?>


                                                                </span>

                                                            </p>

                                                            <p class="text-white">

                                                            <?php echo e(Str::limit(strip_tags($posts->body), 100)); ?>


                                                            </p>

                                                            

                                                            <p class="text-white"><?php echo e(trans('multi-leng.formerror50')); ?>:&nbsp;&nbsp;

                                                                <span class="badge badge-primary even-larger-badge p-2 mb-2" style="font-size:14px;"><?php echo e($posts->titlecat); ?></span>

                                                            </p>

                                                            <p class="text-white">Tags:&nbsp;&nbsp;

                                                                <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inf => $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                    <?php if($info[$inf]['idpost'] == $posts->id): ?>

                                                                        <?php $__currentLoopData = $info[$inf]['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta => $intags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                        <span class="badge badge-primary even-larger-badge p-2 mb-2" style="font-size:14px;">#<?php echo e($info[$inf]['tags'][$ta]['titulo']); ?></span>

                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                    <?php endif; ?>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </p>

                                                        </div>

                                                    </div>

                                                </div>

                                                <div class="card-footer bg-transparent border-0 mb-3">

                                                    <div class="d-flex justify-content-between align-items-center">

                                                        <div class="btn-group">

                                                            <a href="<?php echo e(route('ver-publicacion-completa-usuario', Crypt::encrypt($posts->id))); ?>" class="btn btn-sm btn-primary text-white"><?php echo e(trans('multi-leng.formerror88')); ?></a>

                                                        </div>

                                                        <small class="text-white"><?php echo e($posts->created_at->diffForHumans()); ?></small>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </section>

                                </td>

                            </tr>

                            <?php else: ?>

                            <tr> 

                                <td style="white-space:normal;" data-order="<?php echo e($row); ?>">

                                    <section>

                                        <div class="container py-3">

                                            <div class="card shadow-sm bg-success rounded-3 h-100">

                                                <div class="row ">

                                                    

                                                    <div class="col-md-8 px-3">

                                                        <div class="card-block px-3">

                                                            <a href="#">

                                                                <h3 class="card-text"> <?php echo e($posts->title); ?></h3>

                                                            </a>

                                                            <p class="text-white">

                                                            <?php echo e(trans('multi-leng.formerror25')); ?> <a href="#" class="text-white">&nbsp;<?php echo e($posts->nameus); ?> <?php echo e($posts->surnameus); ?>&nbsp;&nbsp;-</a> 

                                                                <span class="text-white">&nbsp;&nbsp;<?php echo e(trans('multi-leng.formerror78')); ?>: <?php echo e($posts->created_at->format('d-m-Y')); ?>&nbsp;&nbsp;</span>

                                                                <span class="d-inline float-end text-white">

                                                                <i class="fa fa-comment fa-2x text-white" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="<?php echo e(trans('multi-leng.formerror86')); ?> "></i>

                                                                &nbsp;&nbsp;

                                                                    <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inf => $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                        <?php if($info[$inf]['idpost'] == $posts->id): ?>

                                                                            <?php echo e($info[$inf]['nomcom']); ?>


                                                                        <?php endif; ?>

                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                &nbsp;&nbsp;

                                                                </span>

                                                                <span class="d-inline float-end text-white">

                                                                <i class="fa fa-eye fa-2x text-white" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="<?php echo e(trans('multi-leng.formerror87')); ?> "></i>

                                                                &nbsp;&nbsp;<?php echo e((int)$posts->read_count); ?>


                                                                </span>

                                                            </p>

                                                            <p class="text-white">

                                                            <?php echo e(Str::limit(strip_tags($posts->body), 100)); ?>


                                                            </p>

                                                            

                                                            <p class="text-white"><?php echo e(trans('multi-leng.formerror50')); ?>:&nbsp;&nbsp;

                                                                <span class="badge badge-primary even-larger-badge p-2 mb-2" style="font-size:14px;"><?php echo e($posts->titlecat); ?></span>

                                                            </p>

                                                            <p class="text-white">Tags:&nbsp;&nbsp;

                                                                <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inf => $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                    <?php if($info[$inf]['idpost'] == $posts->id): ?>

                                                                        <?php $__currentLoopData = $info[$inf]['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta => $intags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                        <span class="badge badge-primary even-larger-badge p-2 mb-2" style="font-size:14px;">#<?php echo e($info[$inf]['tags'][$ta]['titulo']); ?></span>

                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                    <?php endif; ?>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </p>

                                                        </div>

                                                    </div>

                                                    <div class="col-md-4">

                                                        <img style="background-color:#fff;" src="<?php echo e($posts->thumbnail ? asset('storage/blog/imagenes/'.$posts->thumbnail) : asset('storage/logos/ust3.png')); ?>" class="w-100">

                                                    </div>

                                                </div>

                                                <div class="card-footer bg-transparent border-0 mb-3">

                                                    <div class="d-flex justify-content-between align-items-center">

                                                        <div class="btn-group">

                                                            <small class="text-white"><?php echo e($posts->created_at->diffForHumans()); ?></small>

                                                        </div>

                                                        <a href="<?php echo e(route('ver-publicacion-completa-usuario', Crypt::encrypt($posts->id))); ?>" class="btn btn-sm btn-primary text-white"><?php echo e(trans('multi-leng.formerror88')); ?></a>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </section>

                                </td>

                            </tr>

                            <?php endif; ?>

                            

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>

</div>

<!-- Modal -->

<div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">

      <div class="modal-header">

        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e(trans('multi-leng.admcat')); ?></h5>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>

        </button>

      </div>

      <div class="modal-body" id="modalbody">

        ...

      </div>

      <div class="modal-footer" id="footerbody">

        

      </div>

    </div>

  </div>

</div>

<input type="hidden" id="status" name="status">

<?php $__env->stopSection(); ?>



<?php $__env->startSection('extra-script'); ?>

<script type="text/javascript">

    

    $(document).ready(function() {

        $(function () {

            $('[data-toggle="tooltip"]').tooltip()

        });

        $('#dt-mant-table').DataTable({

            //"dom": 'lfrtip'

            "dom": 'frtip', 

            fixedHeader: true,

            responsive: true,      

            "order": [[ 0, "asc" ]],

            "language": {

                "url": "<?php echo e(asset('json')); ?>/<?php echo e(trans('multi-leng.idioma')); ?>.json"

            }

        });

    });

</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/desarro3/public_html/santotomas/resources/views/docentes/dashboard.blade.php ENDPATH**/ ?>