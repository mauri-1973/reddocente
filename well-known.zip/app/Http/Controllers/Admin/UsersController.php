<?php

namespace App\Http\Controllers\Admin;

use App\User;
use App\Category;
use App\Subcategory;
use App\Resource;
use App\UserResourse;
use App\CategoriesForums;
use App\CategoriesChats;
use App\Book;
use Spatie\Permission\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use App\Mail\MailUsersNew;
use Illuminate\Support\Facades\Mail;
use App\UserLoginLog;
use Image;
use Crypt;

class UsersController extends Controller
{
     /**
    *
    * allow admin only
    *
    */
    public function __construct() {
        //$this->middleware(['role:admin|creator']);
        $this->middleware(['role:admin']);
    }

    /**
     * Display a listing of User.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::where("cargo_us", "Administrador")->paginate(10);

        return view('admin.users.index', compact('users'));
    }
    /**
     * Display a listing of User.
     *
     * @return \Illuminate\Http\Response
     */
    public function indexaca()
    {
        $cat = Category::join('subcategories as sub', 'sub.cat_id', '=', 'categories.id_cat')
                ->get(['categories.*', 'sub.*']);
        $users = User::where("cargo_us", "Docente")->get();

        return view('admin.users.indexaca', compact('users', 'cat'), ['catego' => count($cat)]);
    }
    public function indexest()
    {
        $cat = Category::join('subcategories as sub', 'sub.cat_id', '=', 'categories.id_cat')
        ->join('resources as res', 'res.subcategory_id', '=', 'sub.id_sub')
        ->join('users as us', 'us.id', '=', 'res.user_id')
        ->where('us.cargo_us', 'Docente')
        ->get(['categories.id_cat as idcat', 'categories.name as namecat', 'sub.id_sub as idsub', 'sub.name as namesub', 'us.id as idusu', 'us.name as nombre', 'us.surname as apellido', 'res.id_rec as idrec']);
        $users = User::where("cargo_us", "Estudiante")->get();
        return view('admin.users.indexest', compact('users', 'cat'), ['catego' => count($cat)]);
    }
    public function indexnot()
    {
        $users = User::where("cargo_us", "Periodista")->get();

        return view('admin.users.indexnot', compact('users'));
    }
    /**
     * Display a listing of User.
     *
     * @return \Illuminate\Http\Response
     */
    public function indexLoginLogs()
    {
        $userLoginActivities = UserLoginLog::paginate(10);

        return view('admin.activity.logs', compact('userLoginActivities'));
    }

    /**
     * Show the form for creating new User.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $roles = Role::get()->pluck('name', 'name');
        foreach($roles as $rol)
        {
            switch (true) 
            {
                case (Auth::user()->cargo_us == "Administrador"):
                    return view('admin.users.create', compact('roles'));
                break;
                case (Auth::user()->cargo_us == "Academico"):
                    return view('admin.users.createaca', compact('roles'));
                break;
                case (Auth::user()->cargo_us == "Periodista"):
                    return view('admin.users.createnot', compact('roles'));
                break;
                case (Auth::user()->cargo_us == "Usuario"):
                    return view('admin.users.createest', compact('roles'));
                break;
                default:
                    return redirect()->route('home')->with('danger', trans('multi-leng.error1')."UsersController:create");
                break;
            }
        }
        
    }

    /**
     * Show the form for creating new User.
     *
     * @return \Illuminate\Http\Response
     */
    public function adduser($tipo)
    {
        $roles = Role::get()->pluck('name', 'name');
        foreach($roles as $rol)
        {
            switch (true) 
            {
                case ($tipo == "administradores"):
                    
                    return view('admin.users.create', compact('roles'));
                break;
                case ($tipo == "academicos"):
                    $arraycat = array();
                    $category = Category::all();
                    foreach($category as $cat)
                    {
                        $arraysub = array();
                        $sub = Subcategory::where('cat_id', $cat->id_cat)->get();
                        foreach($sub as $s)
                        {
                            array_push($arraysub, array('idsub' => $s->id_sub, 'nombresub' => $s->name));
                        }
                        array_push($arraycat, array('nombrecat' => $cat->name, 'arraysub' => $arraysub));
                    };
                    return view('admin.users.createaca', compact('roles', 'arraycat'));
                break;
                case ($tipo == "periodistas"):
                    return view('admin.users.createnot', compact('roles'));
                break;
                case ($tipo == "estudiantes"):
                    $arraycat = Category::join('subcategories as sub', 'sub.cat_id', '=', 'categories.id_cat')
                    ->join('resources as res', 'res.subcategory_id', '=', 'sub.id_sub')
                    ->join('users as us', 'us.id', '=', 'res.user_id')
                    ->where('us.cargo_us', 'Docente')
                    ->get(['categories.id_cat as idcat', 'categories.name as namecat', 'sub.id_sub as idsub', 'sub.name as namesub', 'us.id as idusu', 'us.name as nombre', 'us.surname as apellido', 'res.id_rec as idrec']);
                    $arreglo = array();
                    foreach($arraycat as $row)
                    {
                        array_push($arreglo, array("idcat" => $row->idcat,  "namecat" => $row->namecat, "idsub" => $row->idcat, "namesub" => $row->namesub, "iduseresp" => $row->idusu, "idrec" => $row->idrec, "iduser" => $row->nombre." ".$row->apellido));
                    }
                    $val = $this->getPeopleByAge($arreglo);
                    return view('admin.users.createest', compact('roles', 'val'));
                break;
                default:
                    return redirect()->route('home')->with('danger', trans('multi-leng.error1')."Users-Cont: adduser");
                break;
            }
        }
        
    }
    

    /**
     * Store a newly created User in storage.
     *
     * @param  \App\Http\Requests\StoreUsersRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tipo = $request->tipo;
        if($tipo == 1 || $tipo == 4 )
        {
            $request->validate([
                'name' => ['required', 'string', 'max:255'],
                'surname' => ['required', 'string', 'max:255'],
                'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
                'mobile' => ['required', 'numeric', 'digits:9', 'unique:users'],
                'password' => ['required','min:5'],
                'roles.*' => ['required']
            ]);
        }
        if($tipo == 2 || $tipo == 3)
        {
            $request->validate([
                'name' => ['required', 'string', 'max:255'],
                'surname' => ['required', 'string', 'max:255'],
                'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
                'mobile' => ['required', 'numeric', 'digits:9', 'unique:users'],
                'password' => ['required','min:5'],
                'roles.*' => ['required'],
                'subcat.*' => ['required']
            ]);
        }
        
        if($request->avatar != "")
        {
            $request->validate([
                'avatar' => 'image|mimes:jpg,png,jpeg|max:9000|dimensions:min_width=400,min_height=400,max_width=400,max_height=400'
            ]);
        }
        $nameSanitize = filter_var(ucwords($request->name), FILTER_SANITIZE_STRING);
        $surnameSanitize = filter_var(ucwords($request->surname), FILTER_SANITIZE_STRING);
        $emailSanitize = filter_var(strtolower($request->email), FILTER_SANITIZE_STRING);
        $mobileSanitize = filter_var($request->mobile, FILTER_SANITIZE_STRING);
        $surnameSanitize = filter_var($request->surname, FILTER_SANITIZE_STRING);
        $emailSanitize = filter_var($request->email, FILTER_SANITIZE_STRING);
        $passSanitize = filter_var($request->password, FILTER_SANITIZE_STRING);
        
        $user = new User;
        $user->name    = $nameSanitize;
        $user->surname    = $surnameSanitize;
        $user->email    = $emailSanitize;
        $user->mobile    = $mobileSanitize;
        $user->password    = bcrypt(filter_var($passSanitize, FILTER_SANITIZE_STRING));
        $user->status_us    = 1;
        if($tipo == 1)
        {
            $user->cargo_us    = "Administrador";
        }
        if($tipo == 2)
        {
            $user->cargo_us    = "Docente";
        }
        if($tipo == 3)
        {
            $user->cargo_us    = "Estudiante";
        }
        if($tipo == 4)
        {
            $user->cargo_us    = "Periodista";
        }
        $user->save();
        $roles = $request->input('roles') ? $request->input('roles') : [];
        $user->assignRole($roles);

        $newImageName = 'sinregistro.png';

        if($file = $request->file('avatar'))
        {
            $newImageName = createavatar($file, $user->id);
        }
        else
        {
            User::where('id', $user->id)->update(['avatar' => $newImageName]);
        }
        $mensaje1 = trans('multi-leng.formerror17');
        if($request->sendmail == 1)
        {
            Mail::to("mauri-1973@outlook.cl")->send(new MailUsersNew($nameSanitize.' '.$surnameSanitize, $passSanitize, $emailSanitize));
            if(Mail::failures() != 0) 
            {
                $mensaje1 = trans('multi-leng.formerror18');
            }   
            else
            {
                $mensaje1 = trans('multi-leng.formerror19');
            }
        }
        
             
        if($tipo == 1)
        {
            return redirect()->route('agregar-usuarios-administradores')->with('success', trans('multi-leng.formerror15').$nameSanitize." ".$surnameSanitize.trans('multi-leng.formerror16').$mensaje1);
        }
        if($tipo == 2)
        {
            foreach($request->subcat as $row => $slice)
            {
                $res = Subcategory::select('carpeta')->where('id_sub', (int)$request->subcat[$row])->first();
                $destino = $res->carpeta;
                $carpeta = date("YmdHis");
                $anexo =  preg_replace("/\s+/", "", trim($nameSanitize)).$carpeta;
                
                $dataClient = new Resource;
                $dataClient->title    = "actualizar";
                $dataClient->author    = "actualizar";
                $dataClient->user_id    = $user->id;
                $dataClient->subcategory_id     = (int)$request->subcat[$row];
                $dataClient->folder = $destino.'/'.$anexo;
                $dataClient->save();

                $path = storage_path('app/public/'.$destino.'/'.$anexo);
                if (!is_dir($path))
                {
                    mkdir($path, 0777, true);
                }
            } 
            return redirect()->route('agregar-usuarios-academicos')->with('success', trans('multi-leng.formerror15').$nameSanitize." ".$surnameSanitize.trans('multi-leng.formerror16').$mensaje1);
        }
        if($tipo == 3)
        {
            foreach($request->subcat as $row => $slice)
            {
                $dataClient = new UserResourse;
                $dataClient->id_us    = $user->id;
                $dataClient->id_res   = (int)$request->subcat[$row];
                $dataClient->status   = "habilitado";
                $dataClient->save();
            }
            return redirect()->route('agregar-usuarios-estudiantes')->with('success', trans('multi-leng.formerror15').$nameSanitize." ".$surnameSanitize.trans('multi-leng.formerror16').$mensaje1);
        }
        if($tipo == 4)
        {
            return redirect()->route('agregar-usuarios-noticias')->with('danger', trans('multi-leng.formerror15').$nameSanitize." ".$surnameSanitize.trans('multi-leng.formerror16').$mensaje1);
        }
        

        
    }


    /**
     * Show the form for editing User.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $roles = Role::get()->pluck('name', 'name');

        $user = User::findOrFail($id);

        $data = $user->roles()->pluck('name');
        $selectedRoles = $data[0];
        $select = [];
        $arraycat = array();
        if($selectedRoles == "docente")
        {
            
            $category = Category::all();
            foreach($category as $cat)
            {
                $arraysub = array();
                $sub = Subcategory::where('cat_id', $cat->id_cat)->get();
                foreach($sub as $s)
                {
                    
                    $validador = Resource::where(['subcategory_id' => $s->id_sub, "user_id" => $id])->count();
                    if($validador > 0)
                    {
                        $select[] = $s->id_sub;
                    }
                    array_push($arraysub, array('idsub' => $s->id_sub, 'nombresub' => $s->name ));
                }
                array_push($arraycat, array('nombrecat' => $cat->name, 'arraysub' => $arraysub));
            };

        }

        return view('admin.users.edit', compact('user', 'roles','selectedRoles'), ["arraycat" => $arraycat, "select" => $select]);
    }

    /**
     * Update User in storage.
     *
     * @param  \App\Http\Requests\UpdateUsersRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $id = Crypt::decrypt($id);
        
        
        
        if($request->avatar != "")
        {
            $request->validate([
                'avatar' => 'image|mimes:jpg,png,jpeg|max:9000|dimensions:min_width=400,min_height=400,max_width=400,max_height=400'
            ]);
        }
        if($request->tipo == 0)
        {
            $request->validate([
                'name' => ['required', 'string', 'max:255'],
                'surname' => ['required', 'string', 'max:255'],
                'email' => ['required','string', 'email', 'max:255', Rule::unique('users')->ignore($id)],
                'mobile' => ['required', 'numeric', 'digits:9', Rule::unique('users')->ignore($id)],
                'profesion' => ['required', 'string', 'max:50'],
                'subcat' => ['required'],
            ]);
        }
        else
        {
            $request->validate([
                'name' => ['required', 'string', 'max:255'],
                'surname' => ['required', 'string', 'max:255'],
                'email' => ['required','string', 'email', 'max:255', Rule::unique('users')->ignore($id)],
                'mobile' => ['required', 'numeric', 'digits:9', Rule::unique('users')->ignore($id)],
                'profesion' => ['required', 'string', 'max:50'],
            ]);
        }

        $user = User::findOrFail($id);

        if($request->password != "")
        {
            $request->validate([
                'password' => ['nullable','min:5']
            ]);
            $user->update(['password' => bcrypt($request->password)]);
        }

        if($file = $request->file('avatar'))
        {
            $newImageName = createavatar($file, $id);
        }

        
        $user->update(['name' => $request->name, 'surname' => $request->surname, 'email' => $request->email, 'mobile' => $request->mobile, 'profesion' => $request->profesion]);


        if($request->tipo == 0)
        {
            $arraysubcat = [];
            $arrayresour = [];
            $new = [];
            $dif = [];
            foreach($request->subcat as $row)
            {
                $arraysubcat[] = (int)$row;
            }
            $res = Resource::select('subcategory_id')->where(['user_id' => $id])->get();
            foreach($res as $row)
            {
                $arrayresour[] = $row->subcategory_id;
            }
            
            $new = array_intersect($arraysubcat, $arrayresour);
            
            foreach($new as $row)
            {
                unset($arrayresour[$row]); //array para eliminar
            }

            $array1 = $arrayresour;
            $array2 = $new;
            foreach ($array2 as $valor) {
                foreach ($array1 as $valor2) {
                    if($valor == $valor2){
                        $borrar=array_search($valor,$array1);
                        unset($array1[$borrar]);            
                    }   
                }
            }

            $dif = array_diff($arraysubcat, $arrayresour);

            //dd(['ingresar' => $dif, 'eliminay' =>  $array1 ]);
            foreach($dif as $row)
            {
                $res = Resource::select('subcategory_id')->where(['user_id' => $id, 'subcategory_id' => (int)$row])->withTrashed()->count();
                if($res == 1)
                {
                    $idrec = [];

                    $rec = Resource::select('id_rec')->where(['subcategory_id' => (int)$row ])->withTrashed()->get();

                    foreach($rec as $row1)
                    {
                        $idrec[] = $row1->id_rec;
                    }
                    
                    $catfor = CategoriesForums::where('idres', $idrec)->withTrashed()->count();
                    if($catfor > 0)
                    {
                        $catfor = CategoriesForums::where('idres', $idrec)->restore();
                    }
                    
                    $catchat = CategoriesChats::where('idres', $idrec)->withTrashed()->count();
                    if($catchat > 0)
                    {
                        $catchat = CategoriesChats::where('idres', $idrec)->restore();
                    }

                    $catbook = Book::where('resource_id', $idrec)->withTrashed()->count();
                    if($catbook > 0)
                    {
                        $catbook = Book::where('resource_id', $idrec)->restore();
                    }

                    Resource::where(['user_id' => $id, 'subcategory_id' => (int)$row])->restore();
                }
                else
                {
                    $res = Subcategory::select('carpeta')->where('id_sub', (int)$row)->first();
                    $destino = $res->carpeta;
                    $carpeta = date("YmdHis");
                    $anexo =  preg_replace("/\s+/", "", trim($request->name)).$carpeta;
                    
                    $dataClient = new Resource;
                    $dataClient->title    = "actualizar";
                    $dataClient->author    = "actualizar";
                    $dataClient->user_id    = $id;
                    $dataClient->subcategory_id     = (int)$row;
                    $dataClient->folder = $destino.'/'.$anexo;
                    $dataClient->save();

                    $path = storage_path('app/public/'.$destino.'/'.$anexo);
                    if (!is_dir($path))
                    {
                        mkdir($path, 0777, true);
                    }
                }
                

            }
            foreach($array1 as $row)
            {
                $res = Resource::select('subcategory_id')->where(['user_id' => $id, 'subcategory_id' => (int)$row ])->count();
                
                if($res == 1)
                {
                    $res = Resource::select('*')->where(['user_id' => $id, 'subcategory_id' => (int)$row ])->first();
                    if($res->deleted_at == '')
                    {
                        $catfor = CategoriesForums::where('idres', $res->id_rec)->delete();

                        $catchat = CategoriesChats::where('idres', $res->id_rec)->delete();

                        $catbook = Book::where('resource_id', $res->id_rec)->delete();

                        Resource::select('subcategory_id')->where(['user_id' => $id, 'subcategory_id' => (int)$row ])->delete();
                    }
                    else
                    {
                        
                        $catfor = CategoriesForums::where('idres', $res->id_rec)->withTrashed()->count();
                        if($catfor > 0)
                        {
                            $catfor = CategoriesForums::where('idres', $res->id_rec)->restore();
                        }
                        
                        $catchat = CategoriesChats::where('idres', $res->id_rec)->withTrashed()->count();
                        if($catchat > 0)
                        {
                            $catchat = CategoriesChats::where('idres', $res->id_rec)->restore();
                        }

                        $catbook = Book::where('resource_id', $res->id_rec)->withTrashed()->count();
                        if($catbook > 0)
                        {
                            $catbook = Book::where('resource_id', $res->id_rec)->restore();
                        }
                        Resource::select('subcategory_id')->where(['user_id' => $id, 'subcategory_id' => (int)$row ])->restore();
                    }
                }
            }
        }
        $user = User::select('cargo_us')->where("id", $id)->first();
        if($user->cargo_us == "Administrador")
        {
            $ruta = "agregar-usuarios-administradores";
        }
        if($user->cargo_us == "Estudiante")
        {
            $ruta = "agregar-usuarios-estudiantes";
        }
        if($user->cargo_us == "Docente")
        {
            $ruta = "agregar-usuarios-academicos";
        }
        if($user->cargo_us == "Periodista")
        {
            $ruta = "agregar-usuarios-noticias";
        }
        return redirect()->route($ruta)->with('success', "The $request->name was updated successfully");
    }

    /**
     * Remove User from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return redirect()->route('users.index')->with('danger', "The $user->name was deleted successfully");
    }

    /**
     * Delete all selected User at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = User::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }

    public function array_value_recursive($key, array $arr)
    {
        $val = array();
        array_walk_recursive($arr, function($v, $k) use($key, &$val){
            if($k == $key) array_push($val, $v);
        });

        return count($val) > 1 ? $val : array_pop($val);
    }

    public function getPeopleByAge($arrPeople)
    {
        $arrAges = array_unique($this->array_value_recursive('iduser', $arrPeople));

        $arrPeopleGroupingByAge = [];
        foreach ($arrAges as $age) {
            $arrPeopleGroupingByAge[$age] = $this->getPeopleForAgeOf($age, $arrPeople);
        }

        return $arrPeopleGroupingByAge;
    }

    public function getPeopleForAgeOf($age, $arrPeople)
    {
        $result = [];
        foreach ($arrPeople as $personData) {
            foreach ($personData as $key => $value) {
                if ($key === 'iduser' && $value === $age) {
                    $result[] = $personData;
                }
            }
        }

        return $result;
    }

}
